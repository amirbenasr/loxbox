$.getScript("map_script.js", function() {
    alert("Script loaded but not necessarily executed.");
    print(relays);
 });